# Orion Database files

These files are used when configuring Orion to use database storage. Details on how to configure Orion
to use database storage are in the [User Documentation](https://docs.orion.pegasys.tech/en/stable/).